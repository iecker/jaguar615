/* Jaguar-jCompany Developer Suite. Powerlogic 2010-2014. Please read licensing information in your installation directory. 
*  Contact Powerlogic for more information or contribute with this project: suporte@powerlogic.com.br - www.powerlogic.com.br  */
package ###NOME_PACOTE###.model;

import javax.enterprise.inject.Specializes;
import com.powerlogic.jcompany.commons.config.stereotypes.SPlcRepository;
import com.powerlogic.jcompany.model.PlcBaseRepository;

@Specializes
@SPlcRepository
public class ###SIGLA_PROJETO###Repository extends PlcBaseRepository {
    
}