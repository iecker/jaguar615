/*  																													
	    			       Jaguar-jCompany Developer Suite.																		
			    		        Powerlogic 2010-2014.
			    		    
		Please read licensing information in your installation directory.Contact Powerlogic for more 
		information or contribute with this project: suporte@powerlogic.com.br - www.powerlogic.com.br																								
*/
package ###NOME_PACOTE###.commons;

import com.powerlogic.jcompany.commons.PlcException;

/**
 * poc. Implementar aqui tratamento de exceções específicas da Aplicação
 */
public class ###SIGLA_PROJETO###Exception extends PlcException {

    public ###SIGLA_PROJETO###Exception()
    {
        super();
    }

}
