/*  																													
	    			       Jaguar-jCompany Developer Suite.
																		
			    		        Powerlogic 2010-2014.
			    		    
		Please read licensing information in your installation directory.Contact Powerlogic for more 
		information or contribute with this project: suporte@powerlogic.com.br - www.powerlogic.com.br																								
*/
package ###NOME_PACOTE###.jcompanyqa;

//import com.powerlogic.jcompany.qa.junit.SuiteFuncional;
import junit.framework.Test;

/**
* 
* Suite de testes funcionais
* Para rodar os testes funcionais, é necessário que esteja no classpath do aplicativo referencia Ã  biblioteca
* jCompany QA: jcompany_qa_funcional, jcompany_qa_funcional_xml e jcompany_qa_funcional_modelo.
* Ã necessário também que seja adicionada a dependencia para o projeto jcompany_qa_funcional no pom.xml do projeto.
* Caso tenha sido preenchido o campo de "Amostra Teste" junto com a criação do caso de uso, as açoes acima já
* terão sido automaticamente executadas, caso contrario, terão que ser feitas manualmente.
* Para maiores informações cosulte o manual jCompany QA Functional Tests.
* 
* Para rodar os testes funcionais em uma suite de testes, utilize o código comentado no metodo estatico suite.
* Cada teste funcional terá que ser adicionado a suite utilizando o método addTestSuite.
* 
*/
public class ###SIGLA_PROJETO###GeralWebTestSuite {

	public static Test suite() {
	
		//SuiteFuncional suite = new SuiteFuncional();
		
		//suite.addTestSuite(MeuWebTest1.class);
		//suite.addTestSuite(MeuWebTest2.class);
		
		//return suite;
		return null;
	}
}
