package ###NOME_PACOTE###.facade;

import com.powerlogic.jcompany.commons.facade.IPlcFacade;

public interface I###SIGLA_PROJETO###Facade extends IPlcFacade{
	
}
