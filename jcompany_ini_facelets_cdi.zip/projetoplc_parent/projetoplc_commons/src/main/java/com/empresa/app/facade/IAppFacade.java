package ###NOME_PACOTE###.facade;

import com.powerlogic.jcompany.commons.facade.IPlcFacade;

public interface IAppFacade extends IPlcFacade{
	
}
