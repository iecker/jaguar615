/* ******************* REDEFINIÇÃES DE META-DADOS GLOBAIS DA EMPRESA **********************
  ********************** Configurações default para toda a empresa *************************
  *******************************************************************************************/

package com.powerlogic.jcompany.config.domain.emp;